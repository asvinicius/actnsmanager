<?php
class SuperModel extends CI_Model{
	
    protected $superid;
    protected $supername;
    protected $supernick;
    protected $superpassword;
    protected $superstatus;


    function __construct() {
        parent::__construct();
        $this->setSuperid(null);
        $this->setSupername(null);
        $this->setSupernick(null);
        $this->setSuperpassword(null);
        $this->setSuperstatus(null);
    }
    
    public function search($aux){
		return true;
    }
	
	public function listing() {
        $this->db->select('*');
        $this->db->order_by("supername", "asc");
        return $this->db->get("super")->result();
    }
	
    function getSuperid() {
        return $this->superid;
    }
    function getSupername() {
        return $this->supername;
    }
    function getSupernick() {
        return $this->supernick;
    }
    function getSuperpassword() {
        return $this->superpassword;
    }
    function getSuperstatus() {
        return $this->superstatus;
    }

    function setSuperid($superid) {
        $this->superid = $superid;
    }
    function setSupername($supername) {
        $this->supername = $supername;
    }
    function setSupernick($supernick) {
        $this->supernick = $supernick;
    }
    function setSuperpassword($superpassword) {
        $this->superpassword = $superpassword;
    }
    function setSuperstatus($superstatus) {
        $this->superstatus = $superstatus;
    }
	
}