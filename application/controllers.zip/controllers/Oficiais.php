<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Oficiais extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('JoinrequestModel');
			$joinrequest = new JoinrequestModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$requests = count($joinrequest->listing());
            $content = array("requests" => $requests);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/bailiffs', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 11, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}