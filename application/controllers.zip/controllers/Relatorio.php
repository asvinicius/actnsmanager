<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novaos extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('SuperModel');
			$super = new SuperModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $super->listing();
            $content = array("super" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addos', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function gerar() {
        if ($this->isLogged()){
			
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function os($osid) {
        if ($this->isLogged()){
			
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/os",
			"allowed_types" => "pdf",
			"encrypt_name" => false
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 3, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}