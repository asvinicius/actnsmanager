<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	
	public function index()	{
		if ($this->isLogged()){
			redirect(base_url('welcome'));
		} else {
            $this->load->view('public/login');
        }
	}
	
	public function signin() {
		if ($this->isLogged()){
			redirect(base_url('welcome'));
		} else {
			$this->load->model("LoginModel");
			$email = $this->input->post("email");
			$password = md5($this->input->post("password"));
			$super = $this->LoginModel->search($email, $password);
			
			if($super){
				if($super['superstatus'] == '1'){
					$session = array(
						'superid' => $super["superid"],
						'nick' => $super["supernick"],
						'role' => $super["superrole"],
						'super' => TRUE,
						'logged' => TRUE
					);

					$this->session->set_userdata($session);

					redirect(base_url('login'));
				} else {
					$loginfail = array(
						"class" => "danger",
						"message" => "Sinto muito!<br />Seu acesso ao sistema não foi permitido.");

					$msg = array("loginfail" => $loginfail);

					$this->load->view('public/login', $msg);
				}
			} else {
				$loginfail = array(
					"class" => "danger",
					"message" => "E-mail ou Senha incorretos");
				
				$msg = array("loginfail" => $loginfail);
				
				$this->load->view('public/login', $msg);
			}
		}
	}
	
	public function signout() {
        $this->session->sess_destroy();
        redirect(base_url());
    }
}