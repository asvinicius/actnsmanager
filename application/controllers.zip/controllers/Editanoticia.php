<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editanoticia extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('CategoryModel');
			$this->load->model('TagModel');

			$category = new CategoryModel();
			$tag = new TagModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listingcategory = $category->listing();
			$listingtag = $tag->listing();
            $content = array("categories" => $listingcategory, "tags" => $listingtag);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addnews', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function prepare($newsid = null) {
        if ($this->isLogged()){		
			$this->load->model('CategoryModel');
			$this->load->model('TagModel');
			$this->load->model('NewsModel');
			$this->load->model('NewsdestroyModel');
			$this->load->model('NewspublishModel');
			$this->load->model('NewstagModel');
			
			$category = new CategoryModel();
			$tag = new TagModel();
			$news = new NewsModel();
			$newsdestroy = new NewsdestroyModel();
			$newspublish = new NewspublishModel();
			$newstag = new NewstagModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listingcategory = $category->listing(); // pega lista de categorias no bd
			$listingtag = $tag->listing(); // pega lista de tags no bd
			$item = $news->search($newsid); // pega a not�cia a ser atualizada no bd
			$publication = $newspublish->specific($newsid); // pega o agendamento de publica��o no bd CASO EXISTA
			$undoing = $newsdestroy->specific($newsid); // pega o agendamento de desativa��o no bd CASO EXISTA
			$listnewstag = $newstag->listing($newsid); // pega as rela��es news tag
			
            $content = array(
				"categories" => $listingcategory, 
				"tags" => $listingtag,
				"news" => $item,
				"publication" => $publication,
				"undoing" => $undoing,
				"listnewstag" => $listnewstag);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/updatenews', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function update() {
        if ($this->isLogged()){
			// Definindo as configura��es dos uploads e carregando as libraries
			//$config['upload_path'] = '../assets/img/news'; quando estiver pronto
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			//carregando os models a serem utilizados nesta �rea
			$this->load->model('NewsModel');
			$this->load->model('NewsdestroyModel');
			$this->load->model('NewspublishModel');
			$this->load->model('NewstagModel');
			
			//construindo as vari�veis a trabalar com os models
			$news = new NewsModel();
			$newsdestroy = new NewsdestroyModel();
			$newspublish = new NewspublishModel();
			$newstag = new NewstagModel();
			
			//recebendo os posts do formulario
			$newsid = $this->input->post("newsid");
			$newstitle = $this->input->post("newstitle");
			$newsresume = $this->input->post("newsresume");
			$newscontent = $this->input->post("newscontent");
			$newscategory = $this->input->post("newscategory");
			$newstype = $this->input->post("newstype");
			$newsfront = $this->input->post("newsfront");
			$newsthumb = $this->input->post("newsthumb");
			$newsdate = $this->input->post("newsdate");
			$newsslug = $this->input->post("newsslug");
			$newsdraft = $this->input->post("newsdraft");
			
			//upload de umagens
			if($this->upload->do_upload('newsfrontupdate')){
                $imginfo = $this->upload->data();
                $newsfront = $imginfo['file_name'];
            }
			if($this->upload->do_upload('newsthumbupdate')){
                $imginfo = $this->upload->data();
                $newsthumb = $imginfo['file_name'];
            }
			
			$tagcheck = $this->input->post("tagcheck");
			$newspublishdate = $this->input->post("newspublish");
			$newsdestroydate = $this->input->post("newsdestroy");
			
			$destroycancel = $this->input->post("destroycancel");
			$publishcancel = $this->input->post("publishcancel");
			
			//Verificar se � rascunho
			if($newsdraft){
				$newsdata['newsid'] = $newsid;
				$newsdata['newstitle'] = $newstitle;
				$newsdata['newsresume'] = $newsresume;
				$newsdata['newscontent'] = $newscontent;
				$newsdata['newscategory'] = $newscategory;
				$newsdata['newstype'] = $newstype;
				$newsdata['newsfront'] = $newsfront;
				$newsdata['newsthumb'] = $newsthumb;
				$newsdata['newsdate'] = date("Y-m-d");
				$newsdata['newsslug'] = $newsslug;
				$newsdata['newsdraft'] = 1;
				$newsdata['newsscheduled'] = 0;
				$newsdata['newsstatus'] = 0;
				
				if($news->update($newsdata)){
					$relation = $newstag->listing($newsid);
					foreach($relation as $rel){
						$newstag->delete($rel->newstagid);
					}
					
					$relativenews = $newsid;
					
					foreach($tagcheck as $tag){
						$newstagdata['newstagid'] = null;
						$newstagdata['newstagnews'] = $relativenews;
						$newstagdata['newstagtag'] = $tag;
						
						if($newstag->save($newstagdata)){
							
						}
					}
					
					redirect(base_url('noticias'));
				}
			} else {
				if($newspublishdate){
					$newsdata['newsid'] = $newsid;
					$newsdata['newstitle'] = $newstitle;
					$newsdata['newsresume'] = $newsresume;
					$newsdata['newscontent'] = $newscontent;
					$newsdata['newscategory'] = $newscategory;
					$newsdata['newstype'] = $newstype;
					$newsdata['newsfront'] = $newsfront;
					$newsdata['newsthumb'] = $newsthumb;
					$newsdata['newsdate'] = $newspublishdate;
					$newsdata['newsslug'] = $newsslug;
					$newsdata['newsdraft'] = 0;
					$newsdata['newsscheduled'] = 1;
					$newsdata['newsstatus'] = 0;
					
					if($news->update($newsdata)){
						$relation = $newstag->listing($newsid);
						foreach($relation as $rel){
							$newstag->delete($rel->newstagid);
						}
						
						$relativenews = $newsid;
						
						foreach($tagcheck as $tag){
							$newstagdata['newstagid'] = null;
							$newstagdata['newstagnews'] = $relativenews;
							$newstagdata['newstagtag'] = $tag;
							
							if($newstag->save($newstagdata)){
								
							}
						}
						
						$publish = $newspublish->specific($newsid);
						if($publish){
							$newspublishdata['newspublishid'] = $publish['newspublishid'];
							$newspublishdata['newspublishnews'] = $publish['newspublishnews'];
							$newspublishdata['newspublishdate'] = $newspublishdate;
							$newspublishdata['newspublishstatus'] = $publish['newspublishstatus'];
							if($newspublish->update($newspublishdata)){
							}
						} else {
							$newspublishdata['newspublishid'] = null;
							$newspublishdata['newspublishnews'] = $newsid;
							$newspublishdata['newspublishdate'] = $newspublishdate;
							$newspublishdata['newspublishstatus'] = 1;
							if($newspublish->save($newspublishdata)){
							}
						}
						
						if($newsdestroydate){
							$destroy = $newsdestroy->specific($newsid);
							if($destroy){
								$newsdestroydata['newsdestroyid'] = $destroy['newsdestroyid'];
								$newsdestroydata['newsdestroynews'] = $destroy['newsdestroynews'];
								$newsdestroydata['newsdestroydate'] = $newsdestroydate;
								$newsdestroydata['newsdestroystatus'] = $destroy['newsdestroystatus'];
								if($newsdestroy->update($newsdestroydata)){
									redirect(base_url('noticias'));
								}
							} else {
								$newsdestroydata['newsdestroyid'] = null;
								$newsdestroydata['newsdestroynews'] = $newsid;
								$newsdestroydata['newsdestroydate'] = $newsdestroydate;
								$newsdestroydata['newsdestroystatus'] = 1;
								if($newsdestroy->save($newsdestroydata)){
									redirect(base_url('noticias'));
								}
							}
						} else {
							if($destroycancel){
								$destroy = $newsdestroy->specific($newsid);
								if($newsdestroy->delete($destroy['newsdestroyid'])){
									redirect(base_url('noticias'));
								}
							} else {
								redirect(base_url('noticias'));
							}
						}
					}
				} else {
					$newsdata['newsid'] = $newsid;
					$newsdata['newstitle'] = $newstitle;
					$newsdata['newsresume'] = $newsresume;
					$newsdata['newscontent'] = $newscontent;
					$newsdata['newscategory'] = $newscategory;
					$newsdata['newstype'] = $newstype;
					$newsdata['newsfront'] = $newsfront;
					$newsdata['newsthumb'] = $newsthumb;
					$newsdata['newsdate'] = date("Y-m-d");
					$newsdata['newsslug'] = $newsslug;
					$newsdata['newsdraft'] = 0;
					$newsdata['newsscheduled'] = 0;
					$newsdata['newsstatus'] = 1;
					
					if($news->update($newsdata)){
						$relation = $newstag->listing($newsid);
						foreach($relation as $rel){
							$newstag->delete($rel->newstagid);
						}
						
						$relativenews = $newsid;
						
						foreach($tagcheck as $tag){
							$newstagdata['newstagid'] = null;
							$newstagdata['newstagnews'] = $relativenews;
							$newstagdata['newstagtag'] = $tag;
							
							if($newstag->save($newstagdata)){
								
							}
						}
						if($publishcancel){
							$publish = $newspublish->specific($newsid);
							if($newspublish->delete($publish['newspublishid'])){
							}
						}
						
						if($newsdestroydate){
							$destroy = $newsdestroy->specific($newsid);
							if($destroy){
								$newsdestroydata['newsdestroyid'] = $destroy['newsdestroyid'];
								$newsdestroydata['newsdestroynews'] = $destroy['newsdestroynews'];
								$newsdestroydata['newsdestroydate'] = $newsdestroydate;
								$newsdestroydata['newsdestroystatus'] = $destroy['newsdestroystatus'];
								if($newsdestroy->update($newsdestroydata)){
									redirect(base_url('noticias'));
								}
							} else {
								$newsdestroydata['newsdestroyid'] = null;
								$newsdestroydata['newsdestroynews'] = $newsid;
								$newsdestroydata['newsdestroydate'] = $newsdestroydate;
								$newsdestroydata['newsdestroystatus'] = 1;
								if($newsdestroy->save($newsdestroydata)){
									redirect(base_url('noticias'));
								}
							}
						} else {
							if($destroycancel){
								$destroy = $newsdestroy->specific($newsid);
								if($newsdestroy->delete($destroy['newsdestroyid'])){
									redirect(base_url('noticias'));
								}
							} else {
								redirect(base_url('noticias'));
							}
						}
					}
				}
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/img/news",
			"allowed_types" => "jpg|png",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 2, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}