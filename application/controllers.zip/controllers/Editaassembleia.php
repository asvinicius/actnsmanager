<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editaassembleia extends CI_Controller {
	
	public function prepare($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $assembly->search($assemblyid);
			
            $content = array("assembly" => $item);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/updateassembly', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function update() {
        if ($this->isLogged()){
			// Definindo as configura��es dos uploads e carregando as libraries
			//$config['upload_path'] = '../assets/img/news'; quando estiver pronto
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			//recebendo os posts do formulario
			
			$assemblyid = $this->input->post("assemblyid");
			$assemblytopic = $this->input->post("updateassemblytopic");
			$assemblydate = $this->input->post("assemblydate");
			$assemblyplace = $this->input->post("updateassemblyplace");
			$assemblycallnotice = $this->input->post("assemblycallnotice");
			$assemblyminutes = $this->input->post("assemblyminutes");
			$assemblyattending = $this->input->post("assemblyattending");
			$assemblystatus = $this->input->post("assemblystatus");
			
			$updateassemblydate = $this->input->post("updateassemblydate");
			
			//upload de umagens
			if($this->upload->do_upload('updateassemblycallnotice')){
                $imginfo = $this->upload->data();
                $assemblycallnotice = $imginfo['file_name'];
            }
			
			//Verificar se � rascunho
			if($updateassemblydate){
				$assemblydata['assemblyid'] = $assemblyid;
				$assemblydata['assemblytopic'] = $assemblytopic;
				$assemblydata['assemblydate'] = $updateassemblydate;
				$assemblydata['assemblyplace'] = $assemblyplace;
				$assemblydata['assemblycallnotice'] = $assemblycallnotice;
				$assemblydata['assemblyminutes'] = $assemblyminutes;
				$assemblydata['assemblyattending'] = $assemblyattending;
				$assemblydata['assemblystatus'] = $assemblystatus;
				
				if($assembly->update($assemblydata)){
					redirect(base_url('assembleias'));
				}
			} else {
				$assemblydata['assemblyid'] = $assemblyid;
				$assemblydata['assemblytopic'] = $assemblytopic;
				$assemblydata['assemblydate'] = $assemblydate;
				$assemblydata['assemblyplace'] = $assemblyplace;
				$assemblydata['assemblycallnotice'] = $assemblycallnotice;
				$assemblydata['assemblyminutes'] = $assemblyminutes;
				$assemblydata['assemblyattending'] = $assemblyattending;
				$assemblydata['assemblystatus'] = $assemblystatus;
				
				if($assembly->update($assemblydata)){
					redirect(base_url('assembleias'));
				}
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/assembly",
			"allowed_types" => "pdf",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 5, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}