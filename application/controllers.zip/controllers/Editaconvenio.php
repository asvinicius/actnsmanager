<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editaconvenio extends CI_Controller {
	
	public function prepare($covenantid = null) {
        if ($this->isLogged()){
			$this->load->model('CovenantModel');
			$this->load->model('PartnersModel');
			$covenant = new CovenantModel();
			$partners = new PartnersModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$itemcovenant = $covenant->search($covenantid);
			$listpartner = $partners->listactive();
            $content = array("partners" => $listpartner, "covenant" => $itemcovenant);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/updatecovenant', $content);
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function update() {
        if ($this->isLogged()){
			$this->load->model('CovenantModel');
			$covenant = new CovenantModel();
			
			$covenantid = $this->input->post("covenantid");
			$covenantpartner = $this->input->post("covenantpartner");
			$covenantname = $this->input->post("covenantname");
			$covenantype = $this->input->post("covenantype");
			$covenantdescription = $this->input->post("covenantdescription");
			$covenantstatus = $this->input->post("covenantstatus");
			
			$covenantdata['covenantid'] = $covenantid;
			$covenantdata['covenantpartner'] = $covenantpartner;
			$covenantdata['covenantname'] = $covenantname;
			$covenantdata['covenantype'] = $covenantype;
			$covenantdata['covenantdescription'] = $covenantdescription;
			$covenantdata['covenantstatus'] = $covenantstatus;
				
			if($covenant->update($covenantdata)){
				redirect(base_url('convenio/detalhe/'.$covenantid));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	
	public function delete($categoryid = null) {
        if ($this->isLogged()){	
			$this->load->model('CategoryModel');
			$category = new CategoryModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $category->search($categoryid);
			
			if($item){				
				if($category->delete($categoryid)){
					redirect(base_url('categorias'));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/img/partners",
			"allowed_types" => "jpg|png",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}