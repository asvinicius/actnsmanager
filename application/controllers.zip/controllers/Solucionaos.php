<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Solucionaos extends CI_Controller {
		
	public function solucionar($osid) {
        if ($this->isLogged()){
			$page = $this->getPage();
			$pageid = array("page" => $page);
			
			$this->load->model('OrderofserviceModel');
			$this->load->model('OsupdateModel');
			$this->load->model('NotifyModel');
			$this->load->model('SuperModel');
			
			$os = new OrderofserviceModel();
			$osupdate = new OsupdateModel();
			$notify = new NotifyModel();
			$super = new SuperModel();
			
			$order = $os->getos($osid);
			$updates = $osupdate->listing($osid);
			$content = array("order" => $order, "updates" => $updates);
			
			$this->load->view('template/super/header');
			$this->load->view('template/super/menu', $pageid);
			$this->load->view('super/solveos', $content);
        }else{
            redirect(base_url('login'));
        }
    }	
	
	public function solve() {
        if ($this->isLogged()){
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('OrderofserviceModel');
			$this->load->model('OsupdateModel');
			$this->load->model('NotifyModel');
			$this->load->model('SuperModel');
			
			$os = new OrderofserviceModel();
			$osupdate = new OsupdateModel();
			$notify = new NotifyModel();
			$super = new SuperModel();
						
			$osupdatereference = $this->input->post("osupdatereference");
			$osupdatedescription = $this->input->post("osdescription");
            $osupdateattachment = null;
			
			if($this->upload->do_upload('osupdateattachment')){
                $imginfo = $this->upload->data();
                $osupdateattachment = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$osupdatedata['osupdateid'] = null;
			$osupdatedata['osupdatereference'] = $osupdatereference;
			$osupdatedata['osupdateauthor'] = $this->session->userdata('superid');
			$osupdatedata['osupdatedescription'] = $osupdatedescription;
			$osupdatedata['osupdateattachment'] = $osupdateattachment;
			$osupdatedata['osupdatedate'] = date("Y-m-d H:i:s");
			$osupdatedata['osupdatetype'] = 0;
			$osupdatedata['osupdatestatus'] = 1;
			
			if($osupdate->save($osupdatedata)){
				$order = $os->search($osupdatereference);
				
				if($this->setSolve($order)){
					if($this->session->userdata('superid') == $order['osauthor']){
						$newalert = $order['osperformer'];
					} else {
						$newalert = $order['osauthor'];
					}
					if($this->setNotify($order, $newalert)){
						redirect(base_url('os/detalhe/'.$order['osid']));
					}
				}
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/os",
			"allowed_types" => "pdf",
			"encrypt_name" => false
		);
		
		return $config;
	}
	
	public function setSolve($order){
		$this->load->model('OrderofserviceModel');
		$os = new OrderofserviceModel();
		
		$osdata['osid'] = $order['osid'];
		$osdata['osauthor'] = $order['osauthor'];
		$osdata['osperformer'] = $order['osperformer'];
		$osdata['ostitle'] = $order['ostitle'];
		$osdata['osdescription'] = $order['osdescription'];
		$osdata['osdate'] = $order['osdate'];
		$osdata['ospriority'] = $order['ospriority'];
		$osdata['osterm'] = $order['osterm'];
		$osdata['osattachment'] = $order['osattachment'];
		$osdata['osalert'] = 0;
		$osdata['osstatus'] = 0;
		
		if($os->update($osdata)){
			return true;
		}
	}
	
	public function setNotify($order, $osperformer){
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$notifydata['notifyid'] = null;
		$notifydata['notifysuper'] = $osperformer;
		$notifydata['notifydescription'] = "OS solucionada";
		$notifydata['notifylink'] = "os/detalhe/".$order['osid'];
		$notifydata['notifystatus'] = 1;
		
		if($notify->save($notifydata)){
			return true;
		}
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 3, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}