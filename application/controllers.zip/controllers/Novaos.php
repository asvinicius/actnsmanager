<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novaos extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('SuperModel');
			$super = new SuperModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $super->listing();
            $content = array("super" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addos', $content);
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	public function save() {
        if ($this->isLogged()){
			// Definindo as configura��es dos uploads e carregando as libraries
			//$config['upload_path'] = '../assets/img/news'; quando estiver pronto
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			//carregando os models a serem utilizados nesta �rea
			$this->load->model('OrderofserviceModel');
			$this->load->model('NotifyModel');
			$this->load->model('SuperModel');
			
			//construindo as vari�veis a trabalar com os models
			$os = new OrderofserviceModel();
			$notify = new NotifyModel();
			$super = new SuperModel();
						
			//recebendo os posts do formulario
			$ostitle = $this->input->post("ostitle");
			$osperformer = $this->input->post("osperformer");
			$ospriority = $this->input->post("ospriority");
			$osdescription = $this->input->post("osdescription");
			$osattachment = null;
			
			//upload de arquivo
			if($this->upload->do_upload('osattachment')){
                $imginfo = $this->upload->data();
                $osattachment = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
				return false;
			}
			
			$osdata['osid'] = null;
			$osdata['osauthor'] = $this->session->userdata('superid');
			$osdata['osperformer'] = $osperformer;
			$osdata['ostitle'] = $ostitle;
			$osdata['osdescription'] = $osdescription;
			$osdata['osdate'] = date("Y-m-d");
			$osdata['ospriority'] = $ospriority;
			$osdata['osterm'] = $this->getPriority($ospriority);			
			$osdata['osattachment'] = $osattachment;
			$osdata['osalert'] = $osperformer;
			$osdata['osstatus'] = 1;
			
			if($os->save($osdata)){
				$order = $os->lastinsert();
				
				if($this->setNotify($order, $osperformer)){
					$page = $this->getPage();
					$pageid = array("page" => $page);
					
					$content = array("order" => $order);
					
					$this->load->view('template/super/header');
					$this->load->view('template/super/menu', $pageid);
					$this->load->view('super/checkout', $content);
				}
			}
			
			
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function checkout(){
		$page = $this->getPage();
		$pageid = array("page" => $page);
		
		$this->load->model('OrderofserviceModel');
		$this->load->model('NotifyModel');
		$this->load->model('SuperModel');
		
		//construindo as vari�veis a trabalar com os models
		$os = new OrderofserviceModel();
		$notify = new NotifyModel();
		$super = new SuperModel();
		
		$order = $os->getos(1);
		$content = array("order" => $order);
		
		$this->load->view('template/super/header');
		$this->load->view('template/super/menu', $pageid);
		$this->load->view('super/checkout', $content);
	}
	
	public function setNotify($order, $osperformer){
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$notifydata['notifyid'] = null;
		$notifydata['notifysuper'] = $osperformer;
		$notifydata['notifydescription'] = "Nova OS";
		$notifydata['notifylink'] = "os/detalhe/".$order['osid'];
		$notifydata['notifystatus'] = 1;
		
		if($notify->save($notifydata)){
			return true;
		}
	}
	
	public function getPriority($ospriority){
		if($ospriority == 1) {
				return date('Y-m-d', strtotime('+1 week'));
			}
			if($ospriority == 3) {
				if(date('N') > 2){
					return date('Y-m-d', strtotime('+5 day'));
				}else{
					return date('Y-m-d', strtotime('+3 day'));
				}
			}
			if($ospriority == 5) {
				if(date('N') > 4){
					return date('Y-m-d', strtotime('+3 day'));
				}else{
					return date('Y-m-d', strtotime('+1 day'));
				}				
			}
	}
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/os",
			"allowed_types" => "pdf",
			"encrypt_name" => false
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 3, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}