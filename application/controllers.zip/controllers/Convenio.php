<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Convenio extends CI_Controller {
	
	public function detalhe($covenantid = null) {
        if ($this->isLogged()){
			$this->load->model('CovenantModel');
			$covenant = new CovenantModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $covenant->searchdetail($covenantid);
            $content = array("covenant" => $item);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/covenantdetail', $content);
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function mudarstatus($covenantid = null) {
        if ($this->isLogged()){	
			$this->load->model('CovenantModel');
			$covenant = new CovenantModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $covenant->search($covenantid);
			
			if($item){
				$covenantdata['covenantid'] = $item['covenantid'];
				$covenantdata['covenantpartner'] = $item['covenantpartner'];
				$covenantdata['covenantname'] = $item['covenantname'];
				$covenantdata['covenantype'] = $item['covenantype'];
				$covenantdata['covenantdescription'] = $item['covenantdescription'];
				
				if($item['covenantstatus'] == 1){
					$covenantdata['covenantstatus'] = 0;
				} else {
					$covenantdata['covenantstatus'] = 1;
				}
				
				if($covenant->update($covenantdata)){
					redirect(base_url('convenio/detalhe/'.$covenantid));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function delete($covenantid = null) {
        if ($this->isLogged()){	
			$this->load->model('CovenantModel');
			$covenant = new CovenantModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $covenant->search($covenantid);
			
			if($item){				
				if($covenant->delete($covenantid)){
					redirect(base_url('convenios'));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}