<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assembleias extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $assembly->listing();
			$itens = count($assembly->listing());
			
			if(($itens % 10) == 0) {
				$mult = true;
			} else {
				$mult = false;
			}
			
            $content = array("assemblies" => $listing, "page" => 0, "itens" => $itens, "mult" => $mult);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblies', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function pagina($paged) {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $assembly->mypaged($paged);
			$itens = count($assembly->listing());
			
			if(($itens % 10) == 0) {
				$mult = true;
			} else {
				$mult = false;
			}
			
            $content = array("assemblies" => $listing, "page" => $paged, "itens" => $itens, "mult" => $mult);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblies', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function pesquisar() {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$searchlabel = $this->input->post("searchlabel");
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $assembly->searchmenu($searchlabel);
			
            $content = array("assemblies" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblies', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function delete($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
						
			if($assembly->delete($assemblyid)){
				redirect(base_url('assembleias'));
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 5, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}