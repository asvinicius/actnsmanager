<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Os extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('OrderofserviceModel');
			$os = new OrderofserviceModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $os->mylisting($this->session->userdata('superid'));
			$itens = count($os->getCount($this->session->userdata('superid')));
			$content = array("orders" => $listing, "page" => 0, "itens" => $itens);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/orderofservice', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function pagina($paged) {
        if ($this->isLogged()){
			$this->load->model('OrderofserviceModel');
			$os = new OrderofserviceModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$itens = count($os->getCount($this->session->userdata('superid')));
			$listing = $os->mypaged($this->session->userdata('superid'), $paged);
			$content = array("orders" => $listing, "page" => $paged, "itens" => $itens);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/orderofservice', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function pesquisar() {
        if ($this->isLogged()){
			$this->load->model('OrderofserviceModel');
			$os = new OrderofserviceModel();
			
			$searchlabel = $this->input->post("searchlabel");
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $os->searchmenu($this->session->userdata('superid'), $searchlabel);
			
			$content = array("orders" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/orderofservice', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function detalhe($osid) {
        if ($this->isLogged()){
			$page = $this->getPage();
			$pageid = array("page" => $page);
			
			$this->load->model('OrderofserviceModel');
			$this->load->model('OsupdateModel');
			$this->load->model('NotifyModel');
			$this->load->model('SuperModel');
			
			$os = new OrderofserviceModel();
			$osupdate = new OsupdateModel();
			$notify = new NotifyModel();
			$super = new SuperModel();
			
			$order = $os->getos($osid);
			$updates = $osupdate->listing($osid);
			$content = array("order" => $order, "updates" => $updates);
			
			$this->load->view('template/super/header');
			$this->load->view('template/super/menu', $pageid);
			$this->load->view('super/osdetail', $content);
			$this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function atualizar($osid) {
        if ($this->isLogged()){
			$page = $this->getPage();
			$pageid = array("page" => $page);
			
			$this->load->model('OrderofserviceModel');
			$this->load->model('OsupdateModel');
			$this->load->model('NotifyModel');
			$this->load->model('SuperModel');
			
			$os = new OrderofserviceModel();
			$osupdate = new OsupdateModel();
			$notify = new NotifyModel();
			$super = new SuperModel();
			
			$order = $os->getos($osid);
			$updates = $osupdate->listing($osid);
			$content = array("order" => $order, "updates" => $updates);
			
			$this->load->view('template/super/header');
			$this->load->view('template/super/menu', $pageid);
			$this->load->view('super/osdetail', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 3, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}