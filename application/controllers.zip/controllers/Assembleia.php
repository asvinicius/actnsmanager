<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assembleia extends CI_Controller {
	
	public function detalhe($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$this->load->model('AssemblypublishModel');
			$assembly = new AssemblyModel();
			$assemblypublish = new AssemblypublishModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $assembly->search($assemblyid);
			$ap = $assemblypublish->search($assemblyid);
			
            $content = array("assembly" => $item, "publish" => $ap);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblydetail', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function enviardje($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$this->load->model('AssemblypublishModel');
			$assembly = new AssemblyModel();
			$assemblypublish = new AssemblypublishModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $assembly->search($assemblyid);
			$ap = $assemblypublish->search($assemblyid);
			
            $content = array("assembly" => $item, "publish" => $ap);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/sendpublish', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function savedje() {
        if ($this->isLogged()){
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('AssemblypublishModel');
			$assemblypublish = new AssemblypublishModel();
			
			$assemblyid = $this->input->post("assemblyid");
			$apyear = $this->input->post("apyear");
			$apdate = $this->input->post("apdate");
			$apedition = $this->input->post("apedition");
			
			if($this->upload->do_upload('apcontent')){
                $imginfo = $this->upload->data();
                $apcontent = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$apdata['apid'] = null;
			$apdata['apassembly'] = $assemblyid;
			$apdata['apyear'] = $apyear;
			$apdata['apdate'] = $apdate;
			$apdata['apedition'] = $apedition;
			$apdata['apcontent'] = $apcontent;
			$apdata['apstatus'] = 1;
			
			if($assemblypublish->save($apdata)){
				redirect(base_url('assembleia/detalhe/'.$assemblyid));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function enviarata($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$this->load->model('AssemblypublishModel');
			$assembly = new AssemblyModel();
			$assemblypublish = new AssemblypublishModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $assembly->search($assemblyid);
			$ap = $assemblypublish->search($assemblyid);
			
			if($ap){
				$content = array("assembly" => $item, "publish" => $ap);
				
				$this->load->view('template/super/header');
				$this->load->view('template/super/menu', $pageid);
				$this->load->view('super/sendminutes', $content);
			} else {
				redirect(base_url('assembleia/detalhe/'.$assemblyid));
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function saveata() {
        if ($this->isLogged()){
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$assemblyid = $this->input->post("assemblyid");
			
			if($this->upload->do_upload('assemblyminutes')){
                $imginfo = $this->upload->data();
                $assemblyminutes = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$item = $assembly->search($assemblyid);
			
			$assemblydata['assemblyid'] = $assemblyid;
			$assemblydata['assemblytopic'] = $item['assemblytopic'];
			$assemblydata['assemblydate'] = $item['assemblydate'];
			$assemblydata['assemblyplace'] = $item['assemblyplace'];
			$assemblydata['assemblycallnotice'] = $item['assemblycallnotice'];
			$assemblydata['assemblyminutes'] = $assemblyminutes;
			$assemblydata['assemblyattending'] = $item['assemblyattending'];
			$assemblydata['assemblystatus'] = $item['assemblystatus'];
			
			if($assembly->update($assemblydata)){
				redirect(base_url('assembleia/detalhe/'.$assemblyid));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function enviarlista($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $assembly->search($assemblyid);
			
			if($item['assemblyminutes']){
				$content = array("assembly" => $item);
				
				$this->load->view('template/super/header');
				$this->load->view('template/super/menu', $pageid);
				$this->load->view('super/sendattending', $content);
			} else {
				redirect(base_url('assembleia/detalhe/'.$assemblyid));
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function saveattending() {
        if ($this->isLogged()){
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$assemblyid = $this->input->post("assemblyid");
			
			if($this->upload->do_upload('assemblyattending')){
                $imginfo = $this->upload->data();
                $assemblyattending = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$item = $assembly->search($assemblyid);
			
			$assemblydata['assemblyid'] = $assemblyid;
			$assemblydata['assemblytopic'] = $item['assemblytopic'];
			$assemblydata['assemblydate'] = $item['assemblydate'];
			$assemblydata['assemblyplace'] = $item['assemblyplace'];
			$assemblydata['assemblycallnotice'] = $item['assemblycallnotice'];
			$assemblydata['assemblyminutes'] = $item['assemblyminutes'];
			$assemblydata['assemblyattending'] = $assemblyattending;
			$assemblydata['assemblystatus'] = 0;
			
			if($assembly->update($assemblydata)){
				redirect(base_url('assembleia/detalhe/'.$assemblyid));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function pagina($paged) {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $assembly->mypaged($paged);
			$itens = count($assembly->listing());
			
			if(($itens % 10) == 0) {
				$mult = true;
			} else {
				$mult = false;
			}
			
            $content = array("assemblies" => $listing, "page" => $paged, "itens" => $itens, "mult" => $mult);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblies', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function pesquisar() {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$searchlabel = $this->input->post("searchlabel");
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $assembly->searchmenu($searchlabel);
			
            $content = array("assemblies" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/assemblies', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function delete($assemblyid = null) {
        if ($this->isLogged()){	
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
						
			if($assembly->delete($assemblyid)){
				redirect(base_url('assembleias'));
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/assembly",
			"allowed_types" => "pdf",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 5, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}