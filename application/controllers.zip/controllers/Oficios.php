<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Oficios extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/oficios');
        }else{
            redirect(base_url('login'));
        }
    }
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 12, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}