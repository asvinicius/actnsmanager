<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novoconvenio extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){			
			$this->load->model('PartnersModel');
			$partners = new PartnersModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $partners->listactive();
            $content = array("partners" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addcovenant', $content);
			$this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function save() {
        if ($this->isLogged()){
			$this->load->model('CovenantModel');
			$covenant = new CovenantModel();
			
			//recebendo os posts do formulario
			$covenantpartner = $this->input->post("covenantpartner");
			$covenantname = $this->input->post("covenantname");
			$covenantype = $this->input->post("covenantype");
			$covenantdescription = $this->input->post("covenantdescription");
						
			$covenantdata['covenantid'] = null;
			$covenantdata['covenantpartner'] = $covenantpartner;
			$covenantdata['covenantname'] = $covenantname;
			$covenantdata['covenantype'] = $covenantype;
			$covenantdata['covenantdescription'] = $covenantdescription;
			$covenantdata['covenantstatus'] = 1;
			
			if($covenant->save($covenantdata)){
				redirect(base_url('convenios'));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}