<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novafiliacao extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addbailiff');
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function seguir($joinrequestid = null) {
        if ($this->isLogged()){			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$this->load->model('JoinrequestModel');
			$joinrequest = new JoinrequestModel();
			
			$requester = $joinrequest->search($joinrequestid);
            $content = array("requester" => $requester);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addbailiff', $content);
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function save() {
        if ($this->isLogged()){	
			$this->load->model('AddressModel');
			$this->load->model('BailiffModel');
			$this->load->model('PhoneModel');
			$this->load->model('UserModel');
			$address = new AddressModel();
			$bailiff = new BailiffModel();
			$phone = new PhoneModel();
			$user = new UserModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$request = $this->input->post("joinrequestid");
			$username = $this->input->post("username");
			$usernick = $this->input->post("usernick");
			$usercpf = $this->input->post("usernick");
			$useremail = $this->input->post("usernick");
			$bailiffnacionality = $this->input->post("usernick");
			$bailiffnatcounty = $this->input->post("usernick");
			$bailiffnatstate = $this->input->post("usernick");
			$bailiffbirth = $this->input->post("usernick");
			$bailiffrg = $this->input->post("usernick");
			$bailiffmaritalstatus = $this->input->post("usernick");
			$bailiffschooling = $this->input->post("usernick");
			$bailiffvoterreg = $this->input->post("usernick");
			$bailiffvoterzone = $this->input->post("usernick");
			$bailiffvotersection = $this->input->post("usernick");
			$bailiffregistration = $this->input->post("usernick");
			$bailiffoffice = $this->input->post("usernick");
			$bailiffdesignated = $this->input->post("usernick");
			$bailiffjudicialdistrict = $this->input->post("usernick");
			$bailifftrustposition = $this->input->post("usernick");
			$bailiffattachment = $this->input->post("usernick");
			$phonenumber = $this->input->post("usernick");
			$addressstreet = $this->input->post("usernick");
			$addressnumber = $this->input->post("usernick");
			$addresscep = $this->input->post("usernick");
			$addressdistrict = $this->input->post("usernick");
			$addresscounty = $this->input->post("usernick");
			$addressstate = $this->input->post("usernick");
			$addresscomplement = $this->input->post("usernick");
			
			return false;
			 /*
			$categorydata['categoryid'] = null;
			$categorydata['categoryname'] = $categoryname;
			$categorydata['categoryslug'] = $categoryslug;
			$categorydata['categorystatus'] = 1;
			
			if($category->save($categorydata)){
				redirect(base_url('categorias'));
			}
			*/
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 11, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}