<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Parceiros extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('PartnersModel');
			$partners = new PartnersModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$listing = $partners->listing();
            $content = array("partners" => $listing);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/partners', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function mudarstatus($partnerid = null) {
        if ($this->isLogged()){	
			$this->load->model('PartnersModel');
			$partners = new PartnersModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $partners->search($partnerid);
			
			if($item){
				$partnerdata['partnerid'] = $item['partnerid'];
				$partnerdata['partnername'] = $item['partnername'];
				$partnerdata['partnerslug'] = $item['partnerslug'];
				$partnerdata['partnerdescription'] = $item['partnerdescription'];
				$partnerdata['partnerlogo'] = $item['partnerlogo'];
				
				if($item['partnerstatus'] == 1){
					$partnerdata['partnerstatus'] = 0;
				} else {
					$partnerdata['partnerstatus'] = 1;
				}
				
				if($partners->update($partnerdata)){
					redirect(base_url('parceiros'));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function delete($partnerid = null) {
        if ($this->isLogged()){	
			$this->load->model('PartnersModel');
			$partners = new PartnersModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $partners->search($partnerid);
			
			if($item){				
				if($partners->delete($partnerid)){
					redirect(base_url('parceiros'));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}