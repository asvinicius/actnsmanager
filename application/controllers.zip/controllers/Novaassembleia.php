<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novaassembleia extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('AssemblyModel');
			$assembly = new AssemblyModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addassembly');
			$this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function save() {
        if ($this->isLogged()){
			// Definindo as configura��es dos uploads e carregando as libraries
			//$config['upload_path'] = '../assets/img/news'; quando estiver pronto
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			//carregando os models a serem utilizados nesta �rea
			$this->load->model('AssemblyModel');
			
			//construindo as vari�veis a trabalar com os models
			$assembly = new AssemblyModel();
			
			//recebendo os posts do formulario
			$assemblytopic = $this->input->post("assemblytopic");
			$assemblydate = $this->input->post("assemblydate");
			$assemblyplace = $this->input->post("assemblyplace");
			$assemblycallnotice = null;
			
			//upload de umagens
			if($this->upload->do_upload('assemblycallnotice')){
                $imginfo = $this->upload->data();
                $assemblycallnotice = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$assemblydata['assemblyid'] = null;
			$assemblydata['assemblytopic'] = $assemblytopic;
			$assemblydata['assemblydate'] = $assemblydate;
			$assemblydata['assemblyplace'] = $assemblyplace;
			$assemblydata['assemblycallnotice'] = $assemblycallnotice;
			$assemblydata['assemblyminutes'] = null;
			$assemblydata['assemblyattending'] = null;
			$assemblydata['assemblystatus'] = 1;
			
			if($assembly->save($assemblydata)){
				redirect(base_url('assembleias'));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/arq/assembly",
			"allowed_types" => "pdf",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 5, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}