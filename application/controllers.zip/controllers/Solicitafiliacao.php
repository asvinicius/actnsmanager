<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Solicitafiliacao extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){
			$this->load->model('JoinrequestModel');
			$joinrequest = new JoinrequestModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$requests = $joinrequest->listing();
            $content = array("requests" => $requests);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/requests', $content);
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function delete($joinrequestid = null) {
        if ($this->isLogged()){	
			$this->load->model('JoinrequestModel');
			$joinrequest = new JoinrequestModel();
						
			if($joinrequest->delete($joinrequestid)){
				redirect(base_url('solicitafiliacao'));
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 11, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}