<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editaparceiro extends CI_Controller {
	
	public function prepare($partnerid = null) {
        if ($this->isLogged()){
			$this->load->model('PartnersModel');
			$this->load->model('CovenantModel');
			$partners = new PartnersModel();
			$covenant = new CovenantModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $partners->search($partnerid);
            $content = array("partner" => $item);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/updatepartner', $content);
            $this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function update() {
        if ($this->isLogged()){
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			$this->load->model('PartnersModel');
			$partners = new PartnersModel();
			
			$partnerid = $this->input->post("partnerid");
			$partnername = $this->input->post("partnername");
			$partnerslug = $this->input->post("partnerslug");
			$partnerlogo = $this->input->post("partnerlogo");
			$partnerdescription = $this->input->post("partnerdescription");
			$partnerstatus = $this->input->post("partnerstatus");
			
			if($this->upload->do_upload('partnerlogoupdate')){
                $imginfo = $this->upload->data();
                $partnerlogo = $imginfo['file_name'];
            } else {
				
			}
			
			$partnerdata['partnerid'] = $partnerid;
			$partnerdata['partnername'] = $partnername;
			$partnerdata['partnerslug'] = $partnerslug;
			$partnerdata['partnerdescription'] = $partnerdescription;
			$partnerdata['partnerlogo'] = $partnerlogo;
			$partnerdata['partnerstatus'] = $partnerstatus;
				
				if($partners->update($partnerdata)){
					redirect(base_url('parceiro/detalhe/'.$partnerid));
				}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	
	public function delete($categoryid = null) {
        if ($this->isLogged()){	
			$this->load->model('CategoryModel');
			$category = new CategoryModel();
			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
			$item = $category->search($categoryid);
			
			if($item){				
				if($category->delete($categoryid)){
					redirect(base_url('categorias'));
				}
				
			}
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/img/partners",
			"allowed_types" => "jpg|png",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}