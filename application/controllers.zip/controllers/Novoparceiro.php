<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Novoparceiro extends CI_Controller {
	
	public function index() {
        if ($this->isLogged()){			
			$page = $this->getPage();
            $pageid = array("page" => $page);
			
            $this->load->view('template/super/header');
            $this->load->view('template/super/menu', $pageid);
            $this->load->view('super/addpartner');
			$this->load->view('template/super/footer');
        }else{
            redirect(base_url('login'));
        }
    }
	
	public function save() {
        if ($this->isLogged()){
			// Definindo as configura��es dos uploads e carregando as libraries
			//$config['upload_path'] = '../assets/img/news'; quando estiver pronto
			$config = $this->getConfig();
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
			
			//carregando os models a serem utilizados nesta �rea
			$this->load->model('PartnersModel');
			
			//construindo as vari�veis a trabalar com os models
			$partners = new PartnersModel();
			
			//recebendo os posts do formulario
			$partnername = $this->input->post("partnername");
			$partnerslug = $this->input->post("partnerslug");
			$partnerdescription = $this->input->post("partnerdescription");
			$partnerlogo = null;
			
			//upload de umagens
			if($this->upload->do_upload('partnerlogo')){
                $imginfo = $this->upload->data();
                $partnerlogo = $imginfo['file_name'];
            }else{
				echo $this->upload->display_errors();
			}
			
			$partnerdata['partnerid'] = null;
			$partnerdata['partnername'] = $partnername;
			$partnerdata['partnerslug'] = $partnerslug;
			$partnerdata['partnerdescription'] = $partnerdescription;
			$partnerdata['partnerlogo'] = $partnerlogo;
			$partnerdata['partnerstatus'] = 1;
			
			if($partners->save($partnerdata)){
				redirect(base_url('parceiros'));
			}
		} else {
            redirect(base_url('login'));
        }
		
	}
	
	public function getConfig(){
		$config = array(
			"upload_path" => "assets/img/partners",
			"allowed_types" => "jpg|png",
			"encrypt_name" => true
		);
		
		return $config;
	}
	
	public function getPage() {
		$this->load->model('NotifyModel');
		$notify = new NotifyModel();
		
		$unread = count($notify->unread($this->session->userdata('superid')));
		
        $current = array("id" => 6, "page" => "user", "unread" => $unread);
        return array("current" => $current);
    }
}